package com.project.domain;

public enum WorkerStatus {
	SAFE, CAUTION, WARNING
}
