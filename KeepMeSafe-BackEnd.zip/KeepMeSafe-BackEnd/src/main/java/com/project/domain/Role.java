package com.project.domain;

public enum Role {
	ADMIN, WORKER
}
