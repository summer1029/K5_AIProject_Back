package com.project.domain;

public enum Department {
	전기공,배관공,콘크리트공,철근공,목수
}
